from transformers import AutoTokenizer, AutoModel
import torch
import numpy as np
import faiss

tokenizer = AutoTokenizer.from_pretrained('facebook/contriever')
model = AutoModel.from_pretrained('facebook/contriever')

def text_to_vector(text, max_length=512):
    inputs = tokenizer(text, return_tensors='pt', truncation=True, padding=True, max_length=max_length)
    with torch.no_grad():
        outputs = model(**inputs)
    return outputs.last_hidden_state.mean(dim=1).squeeze().cpu().numpy()


import numpy as np
from rank_bm25 import BM25Okapi

def retrieve_documents_with_dynamic(documents, queries, alpha=0.1, threshold=0.4):
    tokenized_docs = [doc.split() for doc in documents]
    bm25 = BM25Okapi(tokenized_docs)
    
    if isinstance(queries, list):
        query_text = " ".join(queries) 
    else:
        query_text = queries

    tokenized_query = query_text.split()
    bm25_scores = np.array(bm25.get_scores(tokenized_query))  

    timestamps = np.arange(len(documents))  
    query_time = timestamps[-1] 

    time_diffs = np.abs(query_time - timestamps)
    time_weights = np.exp(-alpha * time_diffs)

    weighted_scores = bm25_scores * time_weights
    
    relevant_indices = np.where(weighted_scores > threshold)[0]
    
    if len(relevant_indices) == 0:
        top_documents = []
        idx = []
    else:
        idx = relevant_indices.tolist()
        top_documents = [documents[i] for i in idx]
    
    return top_documents, idx
